from controle.controlador_sistema import ControladorSistema


if __name__ == "__main__":
    ControladorSistema().inicializa_sistema()